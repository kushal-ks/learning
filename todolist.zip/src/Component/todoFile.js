import React,{ Component} from 'react';
import './todo.css';

export class ToDo extends Component{
    
    constructor()
    {
        super()
        this.state={
            myList: [],
            newList:[]

        };
        this.add=this._addValue.bind(this);
        this.remove=this._remove.bind(this);
        
        // this.newList=[]
    }
    _remove(e)
    {
      var List = this.state.myList.filter(function(item){
        return item.value.toLowerCase()!=
        e.value.toLowerCase();
      });  
       
     this.setState(
    {
      myList: List
    }     
  	)
    }   
    _addValue(e)
    {    
      e.preventDefault();  
      var value1=document.getElementById('data').value;
      var newList=this.state.myList;
       
      newList.push(
      {                
        value: value1
      }
      )
      this.setState(
      {
        myList: newList
      }
    )
    document.getElementById('data').value='';
    console.log(this.state.myList)
         
    }
    render(){
        return(
          <center>  
            <div className="Tododiv">
              <form>
                <div className="InputArea"> <input type="text" placeholder="Thing to do ToDay" id="data" className="InputField btn"/>
                <button onClick={this.add} className="btn" >ADD</button>
                </div>
              </form>
            <div>  
              <div class="Innerdiv" style={{height:500}}>
                
                    {this.state.myList.map((n, ind)=> {
                        return <div key={n.ind}  className="ListStyle form-control" >{n.value}
                        <button onClick={() => this.remove(n)}  value={n.value} className="Close btn" style={{float: 'right',fontSizeL:20,color:'white'} }>X</button></div>
                    })}
                   
            
              </div>
            </div>
          </div>
          </center>
        )
    }
}

