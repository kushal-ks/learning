import React, { Component } from 'react';
import {ToDo} from './Component/todoFile'
import logo from './logo.svg';
import './App.css';

class App extends Component {
  render() {
    return (
      <body>

     <div className="Header">
      <center><h1 style={{fontSize:40,paddingTop:50,color:'white',fontWeight:'bolder'}}>TODO LIST</h1>
        <input type="text" style={{width:600} } class="form-control"/>
      </center>
     </div>
      <div style={{height:500}}>
      
         <ToDo />
      </div>
      </body>
    );
  }
}

export default App;
