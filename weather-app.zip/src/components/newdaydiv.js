import React,{ Component } from 'react';
import 
class Daydiv extends Component{
  render(){
		return(
			<div></div>
		)
	}
} 