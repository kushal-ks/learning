import React, {Component} from 'react';
export class Friday extends Component{
  render(){
    return(
      <h1>Friday</h1>
    )
  }
}